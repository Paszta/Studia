
$(document).ready(function(){

    var caption = $('#log');
    caption.css({bottom: '1000px', opacity: '0'});
    caption.animate({bottom: '0', opacity: '1'}, "slow");

});
