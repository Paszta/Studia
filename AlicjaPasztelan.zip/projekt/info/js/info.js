$(document).ready(function(){

    var caption = $('#wjazd');
    caption.css({left: '1000px', opacity: '0'});
    caption.animate({left: '0', opacity: '1'}, "slow");

});
